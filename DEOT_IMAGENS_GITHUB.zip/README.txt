DE-OT — IMAGENS PARA O REPOSITÓRIO

Ordem dos arquivos:
01_painel-referencia.png — referência visual do painel
02_mind-flame.png — Mind Flame
03_wallpaper-onda.png — wallpaper de ondas pontilhadas verde/azul
04_mapa-mental-4-tipos-de-media.png — mapa mental: 4 tipos de média
05_mapa-mental-media-mediana-moda.png — mapa mental: média, mediana e moda

Observação: consegui localizar 2 mapas mentais específicos na biblioteca nesta sessão. Não incluí imagens inventadas para os outros 2 mapas.

Sugestão de pasta no GitHub:
assets/
  01_painel-referencia.png
  02_mind-flame.png
  03_wallpaper-onda.png
  04_mapa-mental-4-tipos-de-media.png
  05_mapa-mental-media-mediana-moda.png
